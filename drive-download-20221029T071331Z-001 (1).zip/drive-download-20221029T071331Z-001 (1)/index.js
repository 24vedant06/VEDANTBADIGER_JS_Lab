// Define the quiz questions
const questions = [
    {
      question: "Who is known as the Father of the Nation in India?",
      options: ["Mahatma Gandhi", "Jawaharlal Nehru", "Subhash Chandra Bose", "Sardar Vallabhbhai Patel"],
      answer: 0,
    },
    {
      question: "Which city is the capital of India?",
      options: ["Mumbai", "Kolkata", "Chennai", "New Delhi"],
      answer: 3,
    },
    {
      question: "Who composed the Indian national anthem?",
      options: ["Rabindranath Tagore", "Bhagat Singh", "Sarojini Naidu", "Bankim Chandra Chattopadhyay"],
      answer: 0,
    },
    {
      question: "Which is the highest mountain peak in India?",
      options: ["Nanda Devi", "Kangchenjunga", "Mount Everest", "Annapurna"],
      answer: 1,
    },
  ];
  
  // Get DOM elements
  const questionElement = document.getElementById("question");
  const choicesElements = document.querySelectorAll(".buttons button");
  const progressElement = document.getElementById("progress");
  const scoreElement = document.getElementById("score");
  
  // Quiz variables
  let currentQuestionIndex = 0;
  let score = 0;
  
  // Function to load the current question and choices
  function loadQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesElements.forEach((element, index) => {
      element.textContent = currentQuestion.options[index];
    });
    progressElement.textContent = `Question ${currentQuestionIndex + 1} of ${questions.length}`;
  }
  
  // Function to check the user's answer
  function checkAnswer(event) {
    const selectedChoiceIndex = event.target.id.slice(-1);
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedChoiceIndex == currentQuestion.answer) {
      score++;
    }
    currentQuestionIndex++;
    if (currentQuestionIndex === questions.length) {
      showResult();
    } else {
      loadQuestion();
    }
  }
  
  // Function to display the quiz result
  function showResult() {
    const totalQuestions = questions.length;
    const percentage = (score / totalQuestions) * 100;
    const resultText = `Your score: ${score} / ${totalQuestions} (${percentage.toFixed(2)}%)`;
    
    questionElement.textContent = "Quiz completed!";
    choicesElements.forEach((element) => {
      element.style.display = "none";
    });
    scoreElement.textContent = resultText;
    scoreElement.style.display = "block";
  }
  
  // Add event listeners to the choice buttons
  choicesElements.forEach((element) => {
    element.addEventListener("click", checkAnswer);
  });
  
  // Start the quiz
  loadQuestion();
  